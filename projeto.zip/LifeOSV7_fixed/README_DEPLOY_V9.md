# LifeOS V9 — pacote preparado para Render

Este pacote foi preparado para teste rápido com equipe.

## URLs previstas

- Backend: `https://lifeos-v9-api.onrender.com`
- Frontend: `https://lifeos-v9-frontend.onrender.com`

## Segurança aplicada no ZIP

- Removido `backend/.env`
- Removido `backend/serviceAccountKey.json`
- Removida a cópia duplicada `frontend/backend/` para não expor backend pelo Static Site
- Adicionado `.gitignore` para `.env`, chaves, wallets e caches
- Backend ajustado para ler `FIREBASE_CREDENTIALS_JSON` pelo Render
- Frontend ajustado para apontar para `https://lifeos-v9-api.onrender.com`

## Render — Backend

- Name: `lifeos-v9-api`
- Root Directory: `backend`
- Runtime: `Python 3`
- Build Command: `pip install -r requirements.txt`
- Start Command: `gunicorn "main:create_app()" --bind 0.0.0.0:$PORT --workers 2 --timeout 120`

## Render — Frontend

- Name: `lifeos-v9-frontend`
- Root Directory: `frontend`
- Build Command: vazio
- Publish Directory: `.`

## Variáveis

Veja `backend/RENDER_ENV_V9.md`.
